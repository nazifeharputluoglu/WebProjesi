using System.IO;

namespace odev_2
{
    public partial class Kelime_Ezber : Form
    {
        public static List<(string ing, string tr)> kelimeler = new List<(string, string)>();
        public Kelime_Ezber()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button2.Enabled = false;
            string txtYolu = @"C:\Users\melek\source\repos\odev_2\odev_2\bin\Debug\net8.0-windows";
            if (Directory.Exists(txtYolu))
            {
                string[] dosyalar = Directory.GetFiles(txtYolu, "*.txt");
                foreach (var dosya in dosyalar)
                {
                    comboBox1.Items.Add(Path.GetFileName(dosya));
                }
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            string secilenDosya = comboBox1.SelectedItem.ToString();
            string dosyaYolu = Path.Combine(@"C:\Users\melek\source\repos\odev_2\odev_2\bin\Debug\net8.0-windows", secilenDosya);

            if (File.Exists(dosyaYolu))
            {
                kelimeler.Clear(); 
                string[] satirlar= File.ReadAllLines(dosyaYolu);
               
                foreach(string satir in satirlar)
                {
                  
                    var parcalar = satir.Split("\t");
                    if(parcalar.Length >= 2)
                    {
                        kelimeler.Add((parcalar[0].Trim(), parcalar[1].Trim()));
                    }
                }

                if (kelimeler.Count > 0)
                {
                    button2.Enabled = true;

                }
                else
                {
                    button2.Enabled = false;
                }
            }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            Coktan_Secmeli_Sorular coktan_Secmeli_Sorular = new Coktan_Secmeli_Sorular();
            coktan_Secmeli_Sorular.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
