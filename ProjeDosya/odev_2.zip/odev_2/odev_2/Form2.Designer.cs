﻿namespace odev_2
{
    partial class Coktan_Secmeli_Sorular
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel1 = new Panel();
            label2 = new Label();
            label1 = new Label();
            panel2 = new Panel();
            label3 = new Label();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button4 = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.LightSeaGreen;
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(44, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(716, 59);
            panel1.TabIndex = 0;
            // 
            // label2
            // 
            label2.ForeColor = SystemColors.ButtonFace;
            label2.Location = new Point(638, 12);
            label2.Name = "label2";
            label2.Size = new Size(75, 34);
            label2.TabIndex = 1;
            label2.Text = "label2";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(12, 12);
            label1.Name = "label1";
            label1.Size = new Size(64, 34);
            label1.TabIndex = 0;
            label1.Text = "label1";
            // 
            // panel2
            // 
            panel2.BackColor = Color.SteelBlue;
            panel2.Controls.Add(label3);
            panel2.Location = new Point(44, 77);
            panel2.Name = "panel2";
            panel2.Size = new Size(716, 92);
            panel2.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(333, 32);
            label3.Name = "label3";
            label3.Size = new Size(50, 20);
            label3.TabIndex = 0;
            label3.Text = "label3";
            // 
            // button5
            // 
            button5.Location = new Point(44, 196);
            button5.Name = "button5";
            button5.Size = new Size(360, 73);
            button5.TabIndex = 2;
            button5.Text = "button5";
            button5.UseVisualStyleBackColor = true;
            button5.Click += SecenekTikla;
            // 
            // button6
            // 
            button6.Location = new Point(410, 196);
            button6.Name = "button6";
            button6.Size = new Size(347, 73);
            button6.TabIndex = 3;
            button6.Text = "button6";
            button6.UseVisualStyleBackColor = true;
            button6.Click += SecenekTikla;
            // 
            // button7
            // 
            button7.Location = new Point(44, 275);
            button7.Name = "button7";
            button7.Size = new Size(360, 70);
            button7.TabIndex = 4;
            button7.Text = "button7";
            button7.UseVisualStyleBackColor = true;
            button7.Click += SecenekTikla;
            // 
            // button4
            // 
            button4.Location = new Point(410, 275);
            button4.Name = "button4";
            button4.Size = new Size(347, 70);
            button4.TabIndex = 5;
            button4.Text = "button4";
            button4.UseVisualStyleBackColor = true;
            button4.Click += SecenekTikla;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // Coktan_Secmeli_Sorular
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(806, 385);
            Controls.Add(button4);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Coktan_Secmeli_Sorular";
            Text = "Çoktan Seçmeli Sorular";
            Load += Coktan_Secmeli_Sorular_Load;
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Label label2;
        private Label label1;
        private Label label3;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button4;
        private System.Windows.Forms.Timer timer1;
    }
}