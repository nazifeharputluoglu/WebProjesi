﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace odev_2
{
    public partial class Coktan_Secmeli_Sorular : Form
    {
        private bool hataYapildi = false;
        Random random = new Random();
        int soruIndex = 0;
        int puan = 0;
        List<(string ing, string tr)> sorular = new List<(String, String)>();

        string dogruCevap = "";
        public Coktan_Secmeli_Sorular()
        {
            InitializeComponent();


        }

        private void Coktan_Secmeli_Sorular_Load(object sender, EventArgs e)
        {
            sorular = Kelime_Ezber.kelimeler.OrderBy(x => random.Next()).ToList();
            SonrakiSoru();
            button5.Click += SecenekTikla;
            button6.Click += SecenekTikla;
            button7.Click += SecenekTikla;
            button4.Click += SecenekTikla;
        }

        private void SonrakiSoru()
        {
            hataYapildi = false;
            if (soruIndex >= sorular.Count)
            {
                Application.Exit();
                return;
            }

            var soru = sorular[soruIndex];
            label3.Text = soru.ing;
            dogruCevap = soru.tr;

            List<string> secenekler = new List<string> { dogruCevap };

            while (secenekler.Count < 4)
            {
                var yanlis = sorular[random.Next(sorular.Count)].tr;
                if (!secenekler.Contains(yanlis))
                    secenekler.Add(yanlis);
            }

            secenekler = secenekler.OrderBy(x => random.Next()).ToList();

            button5.Text = secenekler[0];
            button6.Text = secenekler[1];
            button7.Text = secenekler[2];
            button4.Text = secenekler[3];
            foreach (var btn in new[] { button4, button5, button6, button7 })
            {
                btn.BackColor = SystemColors.Control;
            }

            label2.Text = $"Puan: {puan}";
            label1.Text = $"{soruIndex + 1} / {sorular.Count}";
        }

        private void SecenekTikla(object sender, EventArgs e)
        {
            

            Button tiklanan = sender as Button;

            if (tiklanan != null)
            {

                if (tiklanan.Text == dogruCevap)
                {
                    tiklanan.BackColor = Color.Green;
                   
                    if(!hataYapildi)
                    {
                        puan += 10;
                    }

                    timer1.Start();
                }
                else
                {
                    tiklanan.BackColor = Color.Red;
                }
                hataYapildi = true;
            }
        }


        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            soruIndex++;
            SonrakiSoru() ;
        }
    }
}
